export class YourLoginName {
    StudentNumber: string;
    Name: string;
    LoginName: string;
    Campus: string;
    AssignmentTitle: string;
}