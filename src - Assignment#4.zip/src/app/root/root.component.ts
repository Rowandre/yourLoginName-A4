import { Component, OnInit, Input } from '@angular/core';
import { Menu } from '../menu';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styleUrls: ['./root.component.css']
})
export class RootComponent implements OnInit {
  @Input() breakfastList: Menu;
  @Input() lunchList: Menu;
  @Input() dinnerList: Menu;

  constructor() { }

  ngOnInit(): void {
  }

}
