import { Component, OnInit, Input } from '@angular/core';
import { YourLoginName } from '../yourLoginName';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  @Input() headInfo: YourLoginName;

  constructor() { }

  ngOnInit(): void {
  }

}
