import { Injectable } from '@angular/core';
import {YourLoginName } from './yourLoginName';

@Injectable({
  providedIn: 'root'
})
export class PersonaldataService {

  constructor() { }

loadData(): YourLoginName {
  const MYINFO: YourLoginName = 
  {
    StudentNumber: '991531866',
    Name: 'Andrew Rowe',
    LoginName: 'Rowandre',
    Campus: 'Davis',
    AssignmentTitle: 'Assignment#4'
  };
  return MYINFO;
}

}
