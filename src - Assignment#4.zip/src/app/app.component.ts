import { Component, OnInit } from '@angular/core';
import {YourLoginName } from './yourLoginName';
import {PersonaldataService } from './personaldata.service';
import { Menu } from './menu';
import brkfst from '../assets/data/breakfast.json';
import lnch from '../assets/data/lunch.json';
import dnr from '../assets/data/dinner.json';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'yourLoginName-A4';
  myinfo: YourLoginName;
  breakfastData: Menu[] = brkfst.breakfast;
  lunchData: Menu[] = lnch.lunch;
  dinnerData: Menu[] = dnr.dinner;

  constructor(private pService: PersonaldataService){
    console.log(this.breakfastData);
    console.log(this.lunchData);
    console.log(this.dinnerData);

  }


ngOnInit() {
  this.ldService();
}

ldService(): void {
  this.myinfo = this.pService.loadData();
  console.log(this.myinfo);
}
}