import { Component, OnInit, Input } from '@angular/core';
import { Menu } from '../menu';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  @Input() breakfastList: Menu;
  @Input() lunchList: Menu;
  @Input() dinnerList: Menu;

  constructor() { }

  ngOnInit(): void {
  }

}
