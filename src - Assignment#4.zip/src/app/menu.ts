export interface Menu {
    name: string;
    price: string;
    calories: string;
}